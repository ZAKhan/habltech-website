import heroImg from './hero.png';
import web_mob from './web_mob.jpg';
import api from './api.avif';
import right from './right.jpg';
import ui from './ui.jpg';
import rocket from './rocket.webp';
import about_pic from './about.avif';
import librebooking from  './librebooking.png';
import Carrental from   './Car-rental.png'
import bizcore from   './bizcore.avif'
import edutech from   './edutech.jpg'
import Leadingview from   './Leadingview.webp'
import logisticai from   './logisticai.png'
import shopex from   './shopex.jpg'
import sprint from './sprint.png'
import leadview from  './leadview.jpg'
import medicalhub from './medicalhub.jpg'
import oalan from './oalan.jpg'




export {heroImg
, web_mob
, api
, right
, ui
, rocket
, about_pic
, librebooking
,Carrental
,bizcore
,edutech
,Leadingview
,logisticai
,shopex
,sprint
,leadview
,medicalhub,
oalan
};



